package com.example.firstproject.service;

import com.example.firstproject.dto.CoffeeDto;
import com.example.firstproject.entity.Coffee;
import com.example.firstproject.repository.CoffeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Service
public class CoffeeService {
    @Autowired
    private CoffeeRepository coffeeRepository;

    public ResponseEntity<List<Coffee>> index(){
        return ResponseEntity.status(HttpStatus.OK).body(coffeeRepository.findAll());
    }

    public ResponseEntity<Coffee> FindOne(@PathVariable Long id){
        return ResponseEntity.status(HttpStatus.OK).body(coffeeRepository.findById(id).orElse(null));
    }

    public ResponseEntity<Coffee> CreateOne(@RequestBody CoffeeDto dto){
        Coffee coffeeEntity = dto.toEntity();
        return ResponseEntity.status(HttpStatus.CREATED).body(coffeeRepository.save(coffeeEntity));
    }

    public ResponseEntity<Coffee> EditOne(@PathVariable Long id, @RequestBody CoffeeDto dto){
        Coffee coffeeEntity = dto.toEntity();

        Coffee target = coffeeRepository.findById(id).orElse(null);

        if(target == null || id != coffeeEntity.getId()){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        target.patch(coffeeEntity);
        Coffee updated = coffeeRepository.save(target);
        return ResponseEntity.status(HttpStatus.OK).body(updated);
    }

    public ResponseEntity DeleteOne(@PathVariable Long id){
        Coffee target = coffeeRepository.findById(id).orElse(null);

        if(target == null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        coffeeRepository.delete(target);

        return ResponseEntity.status(HttpStatus.OK).body(null);
    }

}
