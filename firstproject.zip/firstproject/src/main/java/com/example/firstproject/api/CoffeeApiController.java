package com.example.firstproject.api;

import com.example.firstproject.dto.CoffeeDto;
import com.example.firstproject.entity.Article;
import com.example.firstproject.entity.Coffee;
import com.example.firstproject.repository.CoffeeRepository;
import com.example.firstproject.service.CoffeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CoffeeApiController {
    @Autowired
    private CoffeeService coffeeService;

    @GetMapping("/api/coffees")
    public ResponseEntity<List<Coffee>> index(){
        return coffeeService.index();
    }

    @GetMapping("/api/coffees/{id}")
    public ResponseEntity<Coffee> FindOne(@PathVariable Long id){
        return coffeeService.FindOne(id);
    }

    @PostMapping("/api/coffees")
    public ResponseEntity<Coffee> CreateOne(@RequestBody CoffeeDto dto){
        return coffeeService.CreateOne(dto);
    }

    @PatchMapping("/api/coffees/{id}")
    public ResponseEntity<Coffee> EditOne(@PathVariable Long id, @RequestBody CoffeeDto dto){
        return coffeeService.EditOne(id, dto);
    }

    @DeleteMapping("/api/coffees/{id}")
    public ResponseEntity DeleteOne(@PathVariable Long id){
        return coffeeService.DeleteOne(id);
    }

}
