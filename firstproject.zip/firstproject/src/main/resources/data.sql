insert into article(id, title, content) values(1, '가가가가', '1111');
insert into article(id, title, content) values(2, '나나나나', '2222');
insert into article(id, title, content) values(3, '다다다다', '3333');

insert into coffee(name, price) values ('아메리카노', '4500');
insert into coffee(name, price) values ('라떼', '5000');
insert into coffee(name, price) values ('카페 모카', '5500');